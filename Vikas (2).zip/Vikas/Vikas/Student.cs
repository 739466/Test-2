﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Vikas
{
    class Student
    {
        private string name;
        private string id;
        private double gpa;
        private double grade1;
        private double grade2;
        private double grade3;
        private double grade4;
        private double grade5;

        private static List<string> ids = new List<string>();
        private static List<Student> students = new List<Student>();


        public string Name { get => name; set => name = value; }
        public string Id { get => id; set => id = value; }
        public double Gpa { get => gpa; set => gpa = value; }
        public double Grade1 { get => grade1; set => grade1 = value; }
        public double Grade2 { get => grade2; set => grade2 = value; }
        public double Grade3 { get => grade3; set => grade3 = value; }
        public double Grade4 { get => grade4; set => grade4 = value; }
        public double Grade5 { get => grade5; set => grade5 = value; }
        public static List<string> Ids { get => ids; set => ids = value; }
        public static List<Student> Students { get => students; set => students = value; }

        public Student(string name, string id)
        {
            this.Name = name;
            this.Id = id;
            this.Gpa = 0;
            this.Grade1 = 0.0;
            this.Grade2 = 0.0;
            this.Grade3 = 0.0;
            this.Grade4 = 0.0;
            this.Grade5 = 0.0;

        }

        public Student(string name, string id, double gpa, double grade1, double grade2, double grade3, double grade4, double grade5)
        {
            this.Name = name;
            this.Id = id;
            this.Gpa = gpa;
            this.Grade1 = grade1;
            this.Grade2 = grade2;
            this.Grade3 = grade3;
            this.Grade4 = grade4;
            this.Grade5 = grade5;
        }

        public override string ToString()
        {
            return "Name: " + Name + "\nId: " + Id + "\nGPA: " + Gpa.ToString();
        }
    }
}
